package com.example.footballpredictor;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.webkit.WebViewClient;
import android.os.Handler;
import android.os.Looper;
import java.io.*;
import java.net.*;
import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends Activity {
    private WebView web;
    private final Handler handler = new Handler(Looper.getMainLooper());
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new NetBridge(), "AndroidNet");
        web.loadUrl("file:///android_asset/index.html"); setContentView(web);
    }
    public class NetBridge {
        @JavascriptInterface public void get(final String url, final String callback) {
            if (url == null || !(url.startsWith("https://www.football-data.co.uk/") || url.startsWith("https://football-data.co.uk/"))) {
                handler.post(() -> web.evaluateJavascript("window."+callback+"(false,'Only football-data.co.uk HTTPS URLs are allowed')", null)); return;
            }
            new Thread(() -> {
                String result; boolean ok = false;
                try {
                    URL u = new URL(url); HttpsURLConnection c = (HttpsURLConnection)u.openConnection();
                    c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setRequestProperty("User-Agent","FootballPredictor/3.0");
                    int code=c.getResponseCode();
                    if(code>=200 && code<300){ InputStream in=c.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buf=new byte[8192]; int n; while((n=in.read(buf))!=-1) out.write(buf,0,n); in.close(); result=out.toString("UTF-8"); ok=true; }
                    else result="HTTP "+code;
                    c.disconnect();
                } catch(Exception e){ result=e.getClass().getSimpleName()+": "+String.valueOf(e.getMessage()); }
                final boolean fok=ok; final String fres=escape(result);
                handler.post(() -> web.evaluateJavascript("window."+callback+"("+fok+",\""+fres+"\")", null));
            }).start();
        }
        private String escape(String s){ return s.replace("\\","\\\\").replace("\"","\\\"").replace("\r","\\r").replace("\n","\\n").replace("\u2028","\\u2028").replace("\u2029","\\u2029"); }
    }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}

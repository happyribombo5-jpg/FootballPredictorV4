# Football Predictor V4 — Real Free Android Project

This is a phone-friendly Android WebView app that runs a real-data football prediction baseline without a paid API key.

## What is included
- Local historical match database in the app (localStorage).
- CSV download/import support.
- Free Football-Data.co.uk results source.
- Elo rating + recent team goal rates + Poisson score distribution.
- Full-time 1X2, double chance, DNB, BTTS, goal totals, team totals and correct-score probabilities.
- Half-time capable architecture and market engine foundation.
- Walk-forward 1X2 backtest.
- League catalog spanning Europe, South America, North America and Asia.
- Market/data-sufficiency warning instead of fabricating minute-market probabilities.

## Important limitation
The free baseline data is not the same thing as a complete SportyBet/Betway event feed. First 5/10/15-minute markets and minute-by-minute markets need reliable goal/event timestamps. Corners, cards, player props and many live markets need richer event-level data. This app therefore does **not** pretend those markets are fully modeled from score-only CSV files.

Football-Data.co.uk currently provides free historical results, match statistics and betting-odds data, with worldwide files and country/league pages. Coverage changes over time, so the app's free source list should be treated as a practical starting dataset rather than a promise of every league on earth.

## Build on an Android phone
### Option A — AndroidIDE / another on-device Gradle IDE
1. Download and unzip this project.
2. Open the folder containing `settings.gradle`.
3. Allow the IDE to sync/download Gradle dependencies.
4. Select the `app` module.
5. Run the debug build.
6. Install the generated APK.

AndroidIDE was designed for building Gradle Android apps on Android devices, but the upstream project is archived, so use a trusted/current distribution if you choose it.

### Option B — GitHub Actions (free cloud build)
1. Create a GitHub repository.
2. Upload this entire project.
3. Add a workflow that runs `./gradlew assembleDebug` (or use Android Studio/Gradle CI).
4. Download the generated APK artifact.

## Data use
The app is intended for personal analysis. Check the terms of any data provider and bookmaker before redistributing data or automating bookmaker access.
